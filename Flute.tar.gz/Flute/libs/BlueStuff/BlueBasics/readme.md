BlueBasics
==========

**BlueBasics** is a [Bluespec SystemVerilog](http://wiki.bluespec.com/bluespec-systemverilog-and-compiler) library of basic helper types.
It currently provides a dictionary type, a monoid typeclass, a list constructor and a virtualizable typeclass.

BlueBasics components do not rely on non standard Bluespec libraries.
