# TagController
Multi-level tag controller for emulating a tagged memory using an in-memory table.
Zeroing of the in memory tag table can be disabled by building with `-D NO_TAGTABLE_ZEROING`.
