CAVEAT 2020-07-14:

  These adapters between AXI4 and AXI4_Lite are checked in here for
  the record; they may be in working or near-working state, but they
  have not been used for some time.  They were each developed for some
  specific need that seems to have gone away.  They are not used in
  the standard Piccolo/Flute/Toooba builds.
