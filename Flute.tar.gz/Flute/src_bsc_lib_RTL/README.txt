These are copies of a few of the Verilog files that are found in any
standard Bluespec bsc distribution at $(BLUESPECDIR)/Verilog
